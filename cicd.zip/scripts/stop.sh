#!/bin/bash
cd /home/ubuntu
sudo docker compose down
