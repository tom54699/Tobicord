#!/bin/bash
cd /home/ubuntu
sudo docker compose up -d 